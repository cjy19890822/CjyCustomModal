//
//  MyPresentationController.h
//  TransitioningAnimationDemo3
//
//  Created by JiongXing on 2016/10/10.
//  Copyright © 2016年 JiongXing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyPresentationController : UIPresentationController <UIViewControllerTransitioningDelegate>

@end
