//
//  JLWindTransition.h
//  JLTransition
//
//  Created by joshuali on 16/7/2.
//  Copyright © 2016年 joshuali. All rights reserved.
//

#import <Foundation/Foundation.h>
@import UIKit;

@interface JLWindTransition : NSObject<UIViewControllerAnimatedTransitioning>

@end
