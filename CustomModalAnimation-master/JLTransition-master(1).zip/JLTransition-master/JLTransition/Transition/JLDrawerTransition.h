//
//  JLDrawerTransition.h
//  JLTransition
//
//  Created by joshuali on 16/6/29.
//  Copyright © 2016年 joshuali. All rights reserved.
//

#import <Foundation/Foundation.h>
@import UIKit;

@interface JLDrawerTransition : NSObject<UIViewControllerAnimatedTransitioning>
@end
